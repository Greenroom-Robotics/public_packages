# ⚠️ WARNING ⚠️

This crate is intended for Zenoh's internal use.

- [Click here for Zenoh's main repository](https://github.com/eclipse-zenoh/zenoh)
- [Click here for Zenoh's documentation](https://zenoh.io)


